# Libraries to install

sudo apt update 
sudo apt install libhdf5-dev
sudo apt install libhdf5-serial-dev
sudo apt install libatlas-base-dev
sudo apt install libjasper-dev 
sudo apt install libqtgui4 
sudo apt install libqt4-test
sudo apt install python3-opencv

sudo pip3 install netifaces psutil google-api-python-client \
                  wiringpi dronekit opencv-python