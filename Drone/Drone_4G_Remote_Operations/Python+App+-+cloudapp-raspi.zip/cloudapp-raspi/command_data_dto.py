class CommandData:
   def __init__(self):
      self.code = None
      self.data = None 