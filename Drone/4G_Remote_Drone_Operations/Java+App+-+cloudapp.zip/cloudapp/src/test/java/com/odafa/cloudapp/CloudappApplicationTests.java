package com.odafa.cloudapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudappApplicationTests {

	// @Test
	// void contextLoads() {
	// }

}
