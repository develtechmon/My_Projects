package com.odafa.cloudapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudappApplication.class, args);
	}

}
